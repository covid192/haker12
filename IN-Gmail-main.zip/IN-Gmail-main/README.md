# Tool IN-Gmail 

[![Version](https://img.shields.io/badge/Version-v1.0.0-blue)]()
[![Python](https://img.shields.io/badge/Python-v%2B-blue)]()
[![Telegram](https://img.shields.io/badge/Telegram-blue)](https://t.me/ssscw)


Simple tool to check email if it is connected to email and Instagram

Note / Performance is under development

### System 

-  Linux
-  Windows ( CMD ) 
-  Android ( Termux ) 

### Install Tool

```
-  pkg update && pkg upgrade
-  pkg install python -y
-  pkg install python2 -y
-  pkg install git -y
-  pip install requests
-  git clone https://github.com/kanekikon/IN-Gmail
```


### Run

```
[-] cd IN-Gmail
[-] chmod +x IN-Gmail.py
[-] python IN-Gmail.py
```

### Stop

```
[!] Ctrl + Z
```
